<!DOCTYPE html>
<html>
<head>
	<title>Registration Form</title>
	<script>
		 function validation(){
			 	var name = document.forms["regForm"]["firstName"];
			    var name1 = document.forms["regForm"]["lastName"];
				var phone = document.forms["regForm"]["phone"];
				var email = document.forrms["regForm"]["email"];

				if(name.value == ""){
					alert("please insert ur First Name.");
					name.focus();
					return false;
				}

				if(name1.value == ""){
					alert("please insert ur Last Name.");
					name1.focus();
					return false;
				}
				if(phone.value == ""){
					alert("Enter phone no");
					phone.focus();
					return false;
				}
				if(email.value == ""){
					alert("Enter valid email address ");
					phone.focus();
					return false;
				}
				if(email.value.indexof("@",0) < 0){
					alert("Enter valid email address ");
					phone.focus();
					return false;
				}if(email.value.indexof(".",0) < 0 ){
					alert("Enter valid email address ");
					phone.focus();
					return false;
				}

			}
	
	</script>
	<style>
	
	form{
		margin:0 auto;
		width :600px;
	}
	
	</style>
</head>
<body>
	<form name="regForm" action="insert.php" onsubmit="return validation()" method="POST" >
		<fieldset>
				<table>
					<tr>
						<td>First Name</td>
						<td><input type="text" name="firstName"></td>
					</tr>
						 <tr>
							<td>Last Name</td>
							<td><input type="text" name="lastName"></td>
						 </tr>
								<tr>
									<td>Gender</td>
									<td>
										<input required type="radio" name="gender" value="Male">Male
										<input type="radio" name="gender" value="Female">Female
										<input type="radio" name="gender" value="Other">Other 

									</td>
								</tr>
								<tr>
									<td>DOB</td>
									<td>
										<input type="date" name="dob">
									</td>
								</tr>

									<tr>
										<td>CellPhone</td>
										<td><input type="text" name="phone" required minlength="11" ></td>
									</tr>

										<tr>
											<td>EmailID</td>
											<td><input type="text" name="email" required ></td>
										</tr>

										<tr>
											<td>Password</td>
											<td><input type="password" name="password1"></td>
										</tr>

											<tr>
												<td>Confirm Password</td>
												<td><input type="password" name="password2"></td>
											</tr>
									    <tr>
						                
						                   <td>User Type</td>
						                   <td>
							               <select name="selectedType">
								          <!-- <option value="Admin">Admin</option> -->
								           <option value="Seller">Seller</option>
								           <option value="Buyer">Buyer</option>
							               </select>
							               </td>
						                 
					                </tr>

										<tr>
			    	                        <td></td>
			    	                          <td align="right">
			    	                        <!--  <button class="button">Submit</button>
											  <button class="button">Reset</button> --> 
											  
											  <input type="submit" name="submit" value="Submit" >
											  <input type="submit" name="submit" value="Reset">

                                            </td>
			                            </tr>
				</table>
		</fieldset>
	</form>

</body>
</html>
