<?php
     require_once 'db.php';
if(isset($_REQUEST['submit'])){
	$name= trim($_REQUEST['firstName']);
	$name1= trim($_REQUEST['lastName']);
	$date = trim($_REQUEST['dob']);
	$gender=$_REQUEST['gender'];
	$phone=$_REQUEST['phone'];
	$email=trim($_REQUEST['email']);
	$pass1= $_REQUEST['password1'];
	$pass2= $_REQUEST['password2'];
    $selectedType=$_REQUEST['selectedType'];
 
	if(empty($name)==true || empty($name1)==true ||empty($pass1)==true ||empty($pass2) == true || empty($phone)==true ||empty($email)==true || empty($selectedType)==true){
				echo "Fill up Registration form <br>";
	}
	else{
			if($pass1 == $pass2){
				if(!strpos($email, '@')==false){
					$conn = getConnection();

					$name=mysqli_real_escape_string($conn,$name);
					$name1=mysqli_real_escape_string($conn,$name1);
					$date=mysqli_real_escape_string($conn,$date);
					$gender=mysqli_real_escape_string($conn,$gender);
					$phone=mysqli_real_escape_string($conn,$phone);
					$email=mysqli_real_escape_string($conn,$email);
					$pass1=mysqli_real_escape_string($conn,$pass1);
					$pass2=mysqli_real_escape_string($conn,$pass2);

					$pass1=md5($pass1);
					$pass2=md5($pass2);


					$sql = "INSERT INTO user values('null','".$name."','".$name1."' ,'".$date."','".$gender."','".$phone."','".$email."', '".$pass1."','".$pass2."', '".$selectedType."')";
					
					if(mysqli_query($conn, $sql)){
						echo "Sucessfully Registered";
					}else{
						echo "Something went wrong";
						
					}

					mysqli_close($conn);

				}else{
					echo "Invalid Email <br>";
				}
			}else{
			echo "Invalid Password <br>";
		}
	}
}
?>

<html>
	<head></head>
	<body>
	<br><br>
	<a href="home.html">Home</a>

	</body>
</html>