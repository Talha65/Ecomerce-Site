<?php
	session_start();
	session_destroy();  
	setcookie('abc',"987",time()-1,"/"); //
	//session_unset($_SESSION['username']);

	header("location: home.html");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Logout</title>
</head>
<body>
 	<p>Thanks For using our Website</p>
</body>
</html>
