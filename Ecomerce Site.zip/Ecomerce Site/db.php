<?php 


	function getConnection(){

		$conn = mysqli_connect('localhost', 'root', '', 'talha');

		return $conn;
	}


 ?>