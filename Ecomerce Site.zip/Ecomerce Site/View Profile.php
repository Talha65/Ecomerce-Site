<?php
  session_start();

  if($_SESSION['abc']=='123' || $_COOKIE['abc']=="987")
  {

    ?>


			<html>

				<head>
						<style>
						      body{
								  
								  /* border-radious:4px; */
								  height:200px;
								  width:700px;
								  border-style :solid;
								  color :green;
								  border

							  }
						
						</style>
				</head>
				<body>
					<form action="" >
						<?php
						//	session_start();
								require_once 'db.php';
								
								$conn = getConnection();
								
								$_SESSION['abc']="123";
								$email = $_SESSION['email'];
								// echo "<br> Session name " . $name . " <+sdfsfdf <br>";

							//  $sql = "SELECT `id`, `name`, `name1`, `dob`, `gender`, `phone`, `email`, `pass1`, `pass2`, `selectedType` FROM `user` limit 1 ";
								$sql = "SELECT * FROM `user` WHERE email='".$email."' ";
								//echo $sql;
								$result = $conn ->query($sql);
								if($result->num_rows  > 0){
									echo "<table><tr><th>ID</th><th> Name</th><th>Dob</th><th>Gender</th><th>Phone</th><th>Email</th><th>User Type</th></tr>";
									// output data of each row
									while($row = $result->fetch_assoc()) {
										echo "<tr><td>" . $row["id"]. "</td><td>" . $row["name"]. " " . $row["name1"]. "</td><td>" .$row["dob"]."</td><td>" .$row["gender"]. "</td><td>" .$row["phone"]."</td><td>".$row["email"]."</td><td>".$row["selectedType"]."</td></tr>";
									}
									echo "</table>";
								} else {
									echo "0 results";
								}
								mysqli_close($conn);
							
						?>
								<br>
								<a href="adminHome.php">Admin Home</a>
								<a href="updateProfile.php">Update Profile</a>
					
					</form>			

				</body>

			</html>

    
<?php
  }
     else
     {
      header("location: settingAdmin.html");
     }
	 
 ?>
