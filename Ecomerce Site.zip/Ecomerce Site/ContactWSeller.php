
<?php
session_start();

if($_SESSION['abc']=='123' || $_COOKIE['abc']=="987")
  {

    ?>


<?php 
	require_once "db.php";

	if(isset($_REQUEST['status'])){


	}


	$row; 
	$result = ''; 
	$sql = "SELECT * FROM user WHERE selectedType='Seller'" ;
	$conn=getConnection(); 

	if(!mysqli_query($conn, $sql)){
		echo "SQL ERROR";
	}else{
		$result = mysqli_query($conn, $sql);
	}



 ?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Contaact with Seller</title>
	<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
	<script type ="text/javascript" >
    $(document).ready(function(){
	
    $('.search-box input[type="text"]').on("keyup input", function(){
        /* Get input value on change */
		if($(".searchField").val() == "")
		{
			$(".contactinfo").css('background-color', 'white');
		}
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result");
        if(inputVal.length){
            $.get("backendSearch.php", {term: inputVal}).done(function(data){
                // Display the returned data in browser
		
                resultDropdown.html(data);
				$("#hiddenField").html("");
				$("#hiddenField").html(data);
				var id = $(".searchId").val();
				$(".contactinfo").css('background-color', 'white');
				if( typeof(id) == "undefined")
				{
					$(".contactinfo").css('background-color', 'white');
				}
				else{
					$(".contact_"+id).css('background-color', 'lightblue');
				}
		
            });
        } else{
            resultDropdown.empty();
        }
    });
    
    // Set search input value on click of result item
    $(document).on("click", ".result p", function(){
        $(this).parents(".search-box").find('input[type="text"]').val($(this).text());
        $(this).parent(".result").empty();
    });
});
	
	</script>
	

</head>
<body>
	<div id="hiddenField" style="display:none">
    </div>
	
	<h3>Seller List For Contact </h3>
	<table cellspacing="10px" class="table table-responsive">


		<tr>
			<td class="search-box">
			<input class="searchField" type="text" autocomplete="off" placeholder="Search Seller email..." />
			<div class="result"></div>
		   </td>
			<!-- <td></td> -->



		</tr>

		<tr id="header">
			<td>ID</td>
			<td>First Name</td>
			<td>Last Name</td>
			<td>Email</td>
			<td>Contact No</td>
		</tr>
				
				<?php  
				while($row = mysqli_fetch_assoc($result)){ ?>
				<tr class="contact_<?php echo $row['id'] ?> contactinfo">
					<td><?= $row['id'] ?></td>						
					<td><?= $row['name'] ?></td>						
					<td><?= $row['name1'] ?></td>						
					<td><?= $row['email'] ?></td>						
					<td><?= $row['phone'] ?></td>						
				
				</tr>



			
			<?php	}  ?>
	</table>
	<a href="adminHome.php" class="btn btn-primary">Admin Home</a>
</body>
</html>



<?php
            
	 }
	 
     else
     {
      header("location: login.html");
	 }
 ?>

