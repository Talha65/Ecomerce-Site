<?php
session_start();

if($_SESSION['abc']=='123' || $_COOKIE['abc']=="987")
  {

    ?>
<!DOCTYPE html>
<html>
<head>
	<title>settings</title>
	<style>

	</style>
</head>
<body>
        <fieldset style="width: 550px;">
			<legend>settings</legend>
			<form>
				<table style=" width: 125px;border: none;">
					<tr>
						<ul>
						     <li> <a href="View Profile.php"><u style="color: blue"> View Profile </u></a></li>
							 <li> <a href="ChangePassword.php"><u style="color: blue"> Change Password </u></a></li>
							 <li> <a href="AddNewAdmin.php"><u style="color: blue">Add New Admin </u></a></li>
							 <li> <a href="ContactWSeller.php"><u style="color: blue"> Contact with Seller </u></a></li>
							 <li> <a href="Logout.php"><u style="color: blue"> Logout </u></a></li>
					   </ul>
					</tr>
					
				</table>
			</form>
		</fieldset>

 
</body>
</html> 
<?php
            
	 }
	 
     else
     {
      header("location: login.html");
	 }
 ?>
