<?php
session_start();

if($_SESSION['abc']=='123' || $_COOKIE['abc']=="987")
  {

    ?>

<?php 
	require_once "db.php";
	//session_start();

	if(isset($_REQUEST['status'])){
		echo "Buyer Deleted Successfully. <br>";
	}


	$row; 
	$result1 = ''; 
	$query1 = "SELECT * FROM user WHERE selectedType='Buyer'" ;
	$conn=getConnection(); 

	if(!mysqli_query($conn, $query1)){
		echo "SQL ERROR";
	}else{
		$result1 = mysqli_query($conn, $query1);
	}



 ?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Delete Buyer</title>
</head>
<body>
	
	
	<h3>Delete Buyer</h3>
	<table cellspacing="10px" class="table table-responsive">
		<tr id="header">
			<td>ID</td>
			<td>First Name</td>
			<td>Last Name</td>
			<td>Email</td>
			<td>Contact No</td>
			<td>Gender</td>
			<td>Date of Birth</td>
		</tr>
				
				<?php  
				while($row = mysqli_fetch_assoc($result1)){ ?>
				<tr>
					<td> <?= $row['id'] ?> </td>						
					<td><?= $row['name'] ?></td>						
					<td><?= $row['name1'] ?></td>						
					<td><?= $row['email'] ?></td>						
					<td><?= $row['phone'] ?></td>						
					<td><?= $row['gender'] ?></td>
					<td><?= $row['dob'] ?></td>
					<td><a href="delBOPP.php?email=<?= $row['email'] ?>">Delete Buyer</a>
					</td>
				</tr>

			
			<?php	}  ?>
	</table>
	<a href="adminHome.php" class="btn btn-primary">Admin Home</a>
</body>
</html>

<?php
            
		}
		else
		{
		 header("location: login.html");
		}
	?>
