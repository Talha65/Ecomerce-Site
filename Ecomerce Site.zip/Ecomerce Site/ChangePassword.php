<?php
  session_start();
  require_once "db.php";

  if($_SESSION['abc']=='123' || $_COOKIE['abc']=="987")
  {
		if(isset($_REQUEST['submit'])){

			$currPass = $_REQUEST['currPassword'];
			$newPass = $_REQUEST['newpassword'];
			$newPass2 = $_REQUEST['new2password'];
			$email = $_SESSION['email'];
			$result; 


			$conn = getConnection();
			// echo $currPass . " = " .$newPass . " = " .$newPass2;

			if(empty($currPass)==true || empty($newPass)==true || empty($newPass2)==true){
				echo "Fill Up Passwords <br>";
			}else if($newPass!=$newPass2){
				echo "Password did not match <br>"; 
			}else{
				$query = "SELECT * FROM user WHERE email='".$email."' and pass1='".md5($currPass)."'";
				
				
				$result = mysqli_query($conn, $query);
				$row = mysqli_fetch_array($result);
				// print_r($row);
				if($result){
					
					$query2 = "UPDATE user SET pass1='".md5($newPass)."', pass2='".md5($newPass2)."' WHERE email='".$email."'";
					// echo $query2 . "<br>" . $query;
					

					if(mysqli_query($conn, $query2)){
						echo "Password Updated Successfully <br>";
					}else{
						echo "Database Connection Error <br>";
					}

				}else{
					echo "Current Password is Wrong <br>";
				}
			}

		}
  }else{
	header("location: login.html");
	// echo "asd";
	}
	  
	 
 ?>

 <!DOCTYPE html>
<html>
<head>
	<title>ChangePassword</title>
    <style>
		  #from{
			  padding : 25px 160px;
			  background: #B6E0FF;
			  color: #555;
			  display: inline-block;
			  border-radius: 4px;
		  }

		  .changebtn{
			  background :#65C370;
			  border:0;
			  padding:6px 15px ;
			  color:#FFF;
			  text-transform:uppercase;
		  }
	
	</style>

</head>
<body>
	<center>
			<fieldset style="width: 500px;">
			<legend>ChangePassword</legend>
		<form action="" method="post" id="from" >
		
			
			<table style=" width: 250px;border: "1";>
				<tr>
			       <td> CurrentPassword</td>
				   <td><input type="password" name="currPassword"></td>
				</tr>

				<tr>
				   <td>NewPassword</td>
				   <td><input type="password" name="newpassword"></td>
				</tr>

				<tr>
				   <td>Re-NewPassword</td>
				   <td><input type="password" name="new2password"></td>
				</tr>
				

			    <tr>
			    	<td></td>
			    	<td align="right">
						<input type="submit" name="submit" value="change" class="changebtn" >
			         <a href="Login.html"><u style="color: blue"> Login </u></a></td>
                  </td>
			    </tr>
		      
		    </table>
		</fieldset>
      </form>
   </center>
		

</body>
</html>
