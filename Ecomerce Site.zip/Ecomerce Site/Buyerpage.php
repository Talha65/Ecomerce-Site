<!DOCTYPE html>
<html>
<head>
	<title>Online Product Selling</title>
</head>
<body>
<table align="center" border="1">
	
	<tr>
		<td>
		<h1>---Online Product Selling---</h1>
		</td>
	</tr>
</table>
<br><br>

<table align="right" border="1" style="width: 100%">
	<tr>

		<td align="left" style="width: 20%">
			Catagory
		</td>

		<td align="center" style="width: 50%">
					<b>Search For Product</b> <input type="Search" style="width: 65%" name="Search" value="">
					<input type="button" name="SearchSubmit" value="Search" >

		</td>
		<td align="center">
			<SELECT>
				<option hidden="">Cert</option>
				<option>Checkout</option>
			</SELECT>
		</td>

		<td align="center">
			
			<select name="Settings">

				<option value="update" hidden="">Settings</option>
				<option value="update">Update Profile</option>
				<option value="cngpass">Change Password</option>
				<option value="update">Set Payment Method</option>
				<option value="#">Log Out</option>
			
			</select>
				
		</td>

		<td align="center">
			<select>
				<option hidden="">User</option>
				<option>View Profile</option>
			</select>
		</td>

	</tr>

	<table style="width: 20%" style="height: 100%" align="left" border="1">
				<tr>
					<td style="width: 20%">
						<a href="#">Male Prducts</a>
					</td>
				</tr>

				<tr>
					<td>
						<a href="#">Female Prducts</a>
					</td>
				</tr>

				<tr>
					<td>
						<a href="#">Kid's Prducts</a>
					</td>
				</tr>
			</table>

</table>

</body>
</html> 