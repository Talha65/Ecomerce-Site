<?php
session_start();
	require_once 'db.php';
    
	if(isset($_POST['submit'])){
		$email = trim($_POST['email']);
        $pass1 = trim($_POST['pass']);
        
      //  echo $email . " " . $pass1;

		if (empty($email)==true || empty($pass1)==true) {
			echo "Fill up Name and Password <br>";
		}else{
            
            $pass1=md5($pass1);


            $sql = "SELECT * FROM user WHERE email='". $email."' and pass1='". $pass1."'";
           // echo $sql;
            $conn = getConnection();
            
            if($result = mysqli_query($conn, $sql)){
                
                $row = mysqli_fetch_array($result);
              //  echo($row['email']);
              //  echo($row['pass1']);
              //  print_r($row);

                if(isset($_POST['rm'])){
                     setcookie('abc',"987",time()+3600,"/");


                if($row['email']==$email && $row['pass1']==$pass1){                    


                    echo("You are logged in");
                    $_SESSION['abc'] = "123";
                    if($row['selectedType'] == 'ADmin'){
                        $_SESSION['abc'] = "123";
                      //  $_SESSION['name'] = $row['name'];
                        $_SESSION['email'] = $row['email'];
                        
                         header('Location: adminHome.php');

                    }else{
                         header('Location: Seller.html');
                    }
                    
                }else{
                    echo "Invalid User .Please Reg First <br>";
                    // $_SESSION['abc'] = "123";
                    //  header('Location:adminHome.php');
                }
            }
                else
                {
                    if($row['email']==$email && $row['pass1']==$pass1){                    

                    echo("You are logged in");
                    $_SESSION['abc'] = "123";
                    $_SESSION['name'] = $row['name'];
                    $_SESSION['email'] = $row['email'];
                    if($row[9]=='ADmin'){
                       header('Location: adminHome.php');
                    }else{                        
                        header('Location: Seller.html');
                    }
                    
                    }else{
                    echo "Invalid User .Please Reg First <br>";
                  //  $_SESSION['abc'] = "123";
                 //   header('Location:adminHome.php');
                   }
                }

            }	
            else
            {
               // echo "asdfadfa <br>";
               // echo mysqli_errno(). " ". mysqli_error();
            }
		}
	}
 ?>