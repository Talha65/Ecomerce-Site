<?php
	session_start();
    require_once "db.php";


if($_SESSION['abc']=='123' || $_COOKIE['abc']=="987")
  {

	?>
<?php	
	if(isset($_REQUEST['submit'])){

		$fname = trim($_REQUEST['firstName']);
		$lname = trim($_REQUEST['lastName']);
		$phone = $_REQUEST['phone'];
		$email = trim($_SESSION['email']);
        $result; 


$conn = getConnection();
// echo $currPass . " = " .$newPass . " = " .$newPass2;

if(empty($fname)==true || empty($lname)==true || empty($phone)==true ){
	echo "Fill Up the information <br>";

}else{
	$query1 = "SELECT * FROM user WHERE email='".$email."', name = '".$fname."', name1 = '".$lname."', phone = '".$phone."'";
	
	
	$result = mysqli_query($conn, $query1);
	$row = mysqli_fetch_array($result);
	// print_r($row);
	//if($result){
		
		$query2 = "UPDATE user SET name='".$fname."', name1='".$lname."',phone='".$phone."' WHERE email='".$email."'";
		// echo $query2 . "<br>" . $query;
		

		if(mysqli_query($conn, $query2)){
			echo " Updated Successfully <br>";
		}else{
			echo "Database Connection Error <br>";
		}

	//}
	
}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>update</title>
	<script>
		 function validation(){
			 	var name = document.forms["regForm"]["firstName"];
			    var name1 = document.forms["regForm"]["lastName"];

				if(name.value == ""){
					alert("please insert ur First Name.");
					name.focus();
					return false;
				}

				if(name1.value == ""){
					alert("please insert ur Last Name.");
					name1.focus();
					return false;
				}

			}
	
	</script>
</head>
<body>
	<form action="" onsubmit="return validation()" method="POST" >
		<fieldset>
				<table>
					<tr>
						<td>First Name</td>
						<td><input type="text" name="firstName"></td>
					</tr>
						 <tr>
							<td>Last Name</td>
							<td><input type="text" name="lastName"></td>
						 </tr>

						<tr>
							<td>CellPhone</td>
							<td><input type="text" name="phone"   ></td>
						</tr>

						<!-- <tr>
							<td>EmailID</td>
							<td><input type="text" name="email"></td>
						</tr> -->

									
						              
					                

						<tr>
							<td></td>
								<td align="right">
								
								<input type="submit" name="submit" value="Submit" >
								<input type="submit" name="submit" value="Reset">

							</td>
						</tr>
				</table>
		</fieldset>
	</form>

</body>
</html>


<?php
            
     }
     else
     {
      header("location: login.html");
	 }
 ?>
