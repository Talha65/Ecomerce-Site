-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2018 at 04:05 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `talha`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `name1` varchar(40) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(50) NOT NULL,
  `phone` int(11) NOT NULL,
  `email` varchar(40) NOT NULL,
  `pass1` varchar(50) NOT NULL,
  `pass2` varchar(50) NOT NULL,
  `selectedType` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `name1`, `dob`, `gender`, `phone`, `email`, `pass1`, `pass2`, `selectedType`) VALUES
(31, 'tanima', 'chowdhury', '2018-12-03', 'Female', 1521466850, 'tani@gmail.com', '1c4bbdd463dd36e7d80dda5a8e2a6185', '1c4bbdd463dd36e7d80dda5a8e2a6185', 'Buyer'),
(32, 'admin', 'aiub', '2018-10-10', 'other', 1722360666, 'aiub@gmail.com', '21232f297a57a5a743894a0e4a801fc3', '21232f297a57a5a743894a0e4a801fc3', 'ADmin'),
(35, 'anik', 'sorkar', '2018-12-18', 'Male', 1521466857, 'rubaiyat9@gmail.com', 'f2bb10a6e6d5f76cb2d660333079e612', 'f2bb10a6e6d5f76cb2d660333079e612', 'ADmin'),
(36, 'talha', 'chowdhury', '2018-12-10', 'Male', 1722360666, 'atc65chowdhury@gmail.com', '7d2731ef68f1d34e02a42aedaaf68cad', '7d2731ef68f1d34e02a42aedaaf68cad', 'ADmin'),
(38, 'rifat', 'sorkar', '2018-12-01', 'Male', 1777666777, 'rifat@gmail.com', '35c0c28414ac08bb8b6729631f69ee01', '35c0c28414ac08bb8b6729631f69ee01', 'Buyer'),
(42, 'seller1', 'sell1', '2018-12-02', 'Male', 1765498128, 'seller1@gmail.com', '64c9ac2bb5fe46c3ac32844bb97be6bc', '64c9ac2bb5fe46c3ac32844bb97be6bc', 'Seller'),
(45, 'Seller3', 'ssss', '2018-11-04', 'Female', 1521466857, 'seller3@gmail.com', 'ece5ae58b2d51c16c5b61e1266dca96c', 'ece5ae58b2d51c16c5b61e1266dca96c', 'Seller'),
(46, 'seller4', 'ssssssssss', '2017-12-31', 'Male', 1521466857, 'seller4@gmail', '180620f2a84c186d56e0023b3fca2061', '180620f2a84c186d56e0023b3fca2061', 'Seller');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
