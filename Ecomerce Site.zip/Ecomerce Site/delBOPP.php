<?php
session_start();

if($_SESSION['abc']=='123' || $_COOKIE['abc']=="987")
  {

    ?>

<?php require_once 'db.php';
	//session_start();

	$email = $_REQUEST['email'];
	$user = $_REQUEST['user'];
	$conn = getConnection();

		$query = "DELETE FROM user WHERE email='".$email."'";
		if(mysqli_query($conn, $query)){
			header('location: delSeller.php?status=done');
		}else{
			echo "SQL error. <br>";
		}


 ?>

 <?php
            
		}
		else
		{
		 header("location: login.html");
		}
	?>