<?php
session_start();

if($_SESSION['abc']=='123' || $_COOKIE['abc']=="987")
  {

    ?>


<!DOCTYPE html>
<html>
<head>
	<title>New Admin Adding</title>
	<script>
		 function validation(){
			 	var name = document.forms["regForm"]["firstName"];
			    var name1 = document.forms["regForm"]["lastName"];

				if(name.value == ""){
					alert("please insert ur First Name.");
					name.focus();
					return false;
				}

				if(name1.value == ""){
					alert("please insert ur Last Name.");
					name1.focus();
					return false;
				}

			}
	
	</script>
	<style>
	
	form{
		margin:0 auto;
		width :600px;
	}
	
	</style>
</head>
<body>
	<form action="insertNewAdmin.php" onsubmit="return validation()" method="POST" >
		<fieldset>
				<table>
					<tr>
						<td>First Name</td>
						<td><input type="text" name="firstName"></td>
					</tr>
						 <tr>
							<td>Last Name</td>
							<td><input type="text" name="lastName"></td>
						 </tr>
								<tr>
									<td>Gender</td>
									<td>
										<input required type="radio" name="gender" value="Male">Male
										<input type="radio" name="gender" value="Female">Female
										<input type="radio" name="gender" value="Other">Other 

									</td>
								</tr>
								<tr>
									<td>DOB</td>
									<td>
										<input type="date" name="dob">
									</td>
								</tr>

									<tr>
										<td>CellPhone</td>
										<td><input type="text" name="phone"></td>
									</tr>

										<tr>
											<td>EmailID</td>
											<td><input type="text" name="email"></td>
										</tr>

										<tr>
											<td>Password</td>
											<td><input type="password" name="password1"></td>
										</tr>

											<tr>
												<td>Confirm Password</td>
												<td><input type="password" name="password2"></td>
											</tr>
									    <tr>
						                
						                   <!-- <td>User Type</td>
						                   <td>
							               <select name="selectedType">
							               	<input required type="radio" name="selectedType" value="ADmin">ADmin
								           <option value="Admin">Admin</option> 
								          
							               </select>
							               </td> -->
						                 
					                </tr>

										<tr>
			    	                        <td></td>
			    	                          <td align="right">
			    	                        <!--  <button class="button">Submit</button>
											  <button class="button">Reset</button> --> 
											  
											  <input type="submit" name="submit" value="Submit" >
											  <input type="submit" name="submit" value="Reset">

                                            </td>
			                            </tr>
				</table>
		</fieldset>
	</form>

</body>
</html>

<?php
            
     }
     else
     {
      header("location: login.html");
	 }
 ?>
