<?php
session_start();

if($_SESSION['abc']=='123' || $_COOKIE['abc']=="987")
  {

    ?>


<!doctype html>
<html>
	<head>
		<title>AdminHome</title>

	</head>
	<body>
		<form action="">
			<table  border="1px" width="50%" align="center" >
				<legend align="center" >AdminHome</legend>

				<tr >
					<th colspan="2">Seller</th>
						
					<tr>
						<td> <a style="text-decoration:  none; " href="addSeller.php"> ADD Seller</a></td>
						<td> <a style="text-decoration: none;" href="delSeller.php"> Del Seller</a></td>
					</tr>

					<th colspan="2">Buyer</th>
						
					<tr>
						<td> <a style="text-decoration:  none; " href="addBuyer.php"> ADD Buyer</a></td>
						<td> <a style="text-decoration: none;" href="delBuyer.php"> Del Buyer</a></td>
					</tr>


					<th colspan="2" >Product</th>

					<tr>
						<td> <a style="text-decoration: none;" href="publishProduct.html">AddProduct</a> </td>
						<td> <a style="text-decoration: none;" href="deletProduct.html">DelProduct</a> </td>

					</tr>
					<th colspan="2" >Modify</th>
					<tr>
						<td colspan="2"><a style="text-decoration: none;" href="editProductinfo.html" >Product Modification</a></td>
					</tr>

					<th colspan="2" >Hide Product</th>
					<tr>
						<td colspan="2"><a style="text-decoration: none;" href="hide.html" >Product Hide</a></td>
					</tr>
					<th colspan="2" >Setting</th>
					<tr>
						<td colspan="2"><a style="text-decoration: none;" href="settingsAdmin.php" >Settings</a></td>
					</tr>
					
				</tr>

			</table>
		</form>
	</body>
</html>
<?php
            
     }
     else
     {
      header("location: login.html");
	 }
 ?>